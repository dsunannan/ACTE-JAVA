package com.acte.annotations;

import java.lang.annotation.Inherited;

@Inherited
public @interface MyCustomAnnotationInherited {

}
