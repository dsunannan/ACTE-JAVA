package com.acte.annotations;

public class Schedulec {

	// @Schedule(dayOfMonth="last")
	 //@Schedule(dayOfWeek="Fri", hour="23") 
	 public void doPeriodicCleanup() {  }
}
