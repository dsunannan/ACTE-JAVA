package com.acte.annotations;

import java.lang.annotation.Repeatable;

//@Repeatable(Schedulec.class)
public @interface Schedule {

}


