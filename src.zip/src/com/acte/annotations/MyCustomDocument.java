package com.acte.annotations;

import java.lang.annotation.Documented;

@Documented
public @interface MyCustomDocument {

}
