package com.acte.rnd;

public class FinallyWithSExitDemo {

public static void main(String[] args) {
// TO DO Auto-generated method stub
try{
System.exit(0);
}finally{
System.out.println("Hi i am in finally block");
}
}

}
