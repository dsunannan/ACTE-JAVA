package com.acte.accesspecifiers;

public class AccessSpecifiersVariables {
	/*
	 * private,protected and public
	 * If you don't specify any access specifiers then default
	 */
	private int i; //most restrictive
	protected int j;// somewhat restrivtive class + extended class 
	public int k; // Fully acceesible
	 int  m; 
}
