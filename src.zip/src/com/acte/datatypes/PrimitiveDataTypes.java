package com.acte.datatypes;

public class PrimitiveDataTypes {

	public static void main(String[] args) {
		/*
		 * 8 data types
		 */
		// TODO Auto-generated method stub
		byte b_byte=0;
		short s_short=0;
		int i_int=0;
		long l_long=0L;
		
		float f_float=0.0f;
		double d_double=0.0d;
		boolean b_boolean=false;
		char c_char='C';// '\u0001';
		
		System.out.println(b_byte);
		System.out.println(s_short);
		System.out.println(i_int);
		System.out.println(l_long);
		
		System.out.println(f_float);
		System.out.println(d_double);
		System.out.println(b_boolean);
		System.out.println(c_char);

	}

}
