package com.acte.creationalpattern;

public class DemoFactoryPattern {
	
	public static IComputerFactory getComputer(String computername) {
		IComputerFactory icf=null ;
		if(computername.equals("MacBook")) {
			icf = new MacBook();
		}
       if(computername.equals("MiHoriZon")) {
    	   icf = new MiHorizon();
		}
		return icf;
	}

	public static void main(String args[]) {
		IComputerFactory icf = getComputer("MacBook");
		System.out.println(icf.toString());
		
		icf = getComputer("MiHoriZon");
		System.out.println(icf.toString());
	}
}
