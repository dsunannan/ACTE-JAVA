package com.acte.creationalpattern;

 public class Singleton {
	static volatile Singleton singleton;

	private Singleton() {

	}

	public static synchronized Singleton getInstance() {
		if (singleton == null) {
			System.out.println("Constructing singleton..");
			singleton= new Singleton();
			return singleton;
		} else {
			System.out.println("Referring  singleton..");
			return singleton;
		}
	}
}

 

