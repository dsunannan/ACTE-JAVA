package com.acte.creationalpattern;

public interface IComputerFactory {
String getName();
String getRam();
float getCost();
}
