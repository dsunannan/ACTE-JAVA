package com.acte.creationalpattern;

public class MiHorizon implements IComputerFactory {

	@Override
	public String toString() {
		return "MiHorizon [getName()=" + getName() + ", getRam()=" + getRam() + ", getCost()=" + getCost() + "]";
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "MiHoriZon";
	}

	@Override
	public String getRam() {
		// TODO Auto-generated method stub
		return "80GB";
	}

	@Override
	public float getCost() {
		// TODO Auto-generated method stub
		return 100.45f;
	}

}
