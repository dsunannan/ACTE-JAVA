package com.acte.creationalpattern;

public class MacBook implements IComputerFactory {

	@Override
	public String toString() {
		return "MacBook [getName()=" + getName() + ", getRam()=" + getRam() + ", getCost()=" + getCost() + "]";
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "MacBook";
	}

	@Override
	public String getRam() {
		// TODO Auto-generated method stub
		return "128GB";
	}

	@Override
	public float getCost() {
		// TODO Auto-generated method stub
		return 123.45f;
	}

}
