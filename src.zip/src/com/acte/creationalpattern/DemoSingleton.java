package com.acte.creationalpattern;

public class DemoSingleton {
	 public static void main(String args[]) {
		 Singleton s1 = Singleton.getInstance(); 
		 Singleton s2 = Singleton.getInstance();
		 Singleton s3 = Singleton.getInstance();
		 Singleton s4 = Singleton.getInstance();
		 Singleton s5 = Singleton.getInstance();
		 
	 }
}
