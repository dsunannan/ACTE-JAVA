package com.acte.helloworld;

public class A {

	  static void m1() {
		
	}
}
class B extends A {
      static void m1() {
		
	}
}